package com.example.isyscreamcamille.model;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.List;
@Entity
public class TipoSorvete {
   @Id
   @GeneratedValue(strategy = GenerationType.AUTO)
   private int codigo;
   private String tipo;
   private int qntBolas;
   private double peso;
   private String descricao;
   private double valor;
   @OneToMany(mappedBy = "tipoSorvete", cascade = CascadeType.ALL, orphanRemoval = true)
   @JsonIgnore
   private List<Sorvete> sorvetes;
   public int getCodigo() {
       return codigo;
   }
   public void setCodigo(int codigo) {
       this.codigo = codigo;
   }
   public String getTipo() {
       return tipo;
   }
   public void setTipo(String tipo) {
       this.tipo = tipo;
   }
   public int getQntBolas() {
       return qntBolas;
   }
   public void setQntBolas(int qntBolas) {
       this.qntBolas = qntBolas;
   }
   public double getPeso() {
       return peso;
   }
   public void setPeso(double peso) {
       this.peso = peso;
   }
   public String getDescricao() {
       return descricao;
   }
   public void setDescricao(String descricao) {
       this.descricao = descricao;
   }
   public double getValor() {
       return valor;
   }
   public void setValor(double valor) {
       this.valor = valor;
   }
   public List<Sorvete> getSorvetes() {
       return sorvetes;
   }
   public void setSorvetes(List<Sorvete> sorvetes) {
       this.sorvetes = sorvetes;
   }
   @Override
   public String toString() {
       return "TipoSorvete{" +
               "codigo=" + codigo +
               ", tipo='" + tipo + '\'' +
               ", qntBolas=" + qntBolas +
               ", peso=" + peso +
               ", descricao='" + descricao + '\'' +
               ", valor=" + valor +
               '}';
   }
}

