package com.example.isyscreamcamille.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.isyscreamcamille.model.TipoSorvete;

public interface TipoSorveteRepository extends CrudRepository<TipoSorvete, Integer> {

}
