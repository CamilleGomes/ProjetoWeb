package com.example.isyscreamcamille.controller;

import java.sql.SQLException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.isyscreamcamille.model.Sabor;
import com.example.isyscreamcamille.model.Sorvete;
import com.example.isyscreamcamille.model.TipoSorvete;
import com.example.isyscreamcamille.repository.SorveteRepository;
import com.example.isyscreamcamille.repository.TipoSorveteRepository;

@RestController
@RequestMapping("/sorvetes")
public class SorveteController {

    @Autowired
    private SorveteRepository sorveteRepository;

    @Autowired
    private TipoSorveteRepository tipoSorveteRepository;

    public SorveteController(SorveteRepository sorveteRepository, TipoSorveteRepository tipoSorveteRepository) {
        this.sorveteRepository = sorveteRepository;
        this.tipoSorveteRepository = tipoSorveteRepository;
    }

    @PostMapping
    public void createSorvete(@RequestBody Sorvete sorvete) throws SQLException {
        LocalDate localDate = LocalDate.now();
        Instant instant = Instant.from(localDate.atStartOfDay(ZoneId.of("GMT")));
        sorvete.setDataCompra(Date.from(instant));

        // Verifica se a lista de sabores não é nula e contém pelo menos um sabor não nulo
        if (sorvete.getSabores() != null && sorvete.getSabores().stream().anyMatch(sabor -> sabor != null)) {
            TipoSorvete t = tipoSorveteRepository.findById(sorvete.getTipoSorvete().getCodigo()).orElse(null);
            if (t != null) {
                sorvete.setTipoSorvete(t);
            } else {
                throw new IllegalArgumentException("TipoSorvete não encontrado para o código: " + sorvete.getTipoSorvete().getCodigo());
            }
            if (sorvete.getDataCompra() == null) {
                sorvete.setDataCompra(Date.from(Instant.now()));
            }

            if (sorvete.getSabores().stream().anyMatch(sabor -> sabor != null)) {
                sorveteRepository.save(sorvete);
            } else {
                throw new IllegalArgumentException("A lista de sabores não pode ser nula e deve conter pelo menos um sabor não nulo.");
            }
        } else {
            throw new IllegalArgumentException("A lista de sabores não pode ser nula e deve conter pelo menos um sabor não nulo.");
        }
    }

    @GetMapping("/{codigo}")
    public Sorvete readSorvete(@PathVariable int codigo) throws SQLException {
        return sorveteRepository.findById(codigo).orElse(null);
    }

    @GetMapping
    public List<Sorvete> readAllSorvetes() throws SQLException {
        return (List<Sorvete>) sorveteRepository.findAll();
    }

    @PutMapping("/{codigo}")
    public void updateSorvete(@PathVariable int codigo, @RequestBody Sorvete sorvete) throws SQLException {
        sorvete.setCodigo(codigo);
        sorveteRepository.save(sorvete);
    }

    @DeleteMapping("/{codigo}")
    public void deleteSorvete(@PathVariable int codigo) throws SQLException {
        sorveteRepository.deleteById(codigo);
    }

    @GetMapping("/relatorio/{dia}")
    public Map<String, Object> getSorvetesRelatorio(@PathVariable int dia) throws SQLException {
        List<Sorvete> sorvetesAll = (List<Sorvete>) sorveteRepository.findAll();
        List<Sorvete> sorvetesNoDia = new ArrayList<>();
        for (Sorvete sorvete : sorvetesAll) {
            if (sorvete.getDataCompra().toInstant().atZone(ZoneId.systemDefault()).toLocalDate().getDayOfMonth() == dia) {
                sorvetesNoDia.add(sorvete);
            }
        }
        return criarRelatorio(sorvetesNoDia, dia);
    }

    private Map<String, Object> criarRelatorio(List<Sorvete> sorvetes, int dia) {
        Map<String, Object> relatorio = new HashMap<>();
        relatorio.put("quantidadeTotal", sorvetes.size());

        List<String> nomesSabores = new ArrayList<>();
        List<String> descricoesTipos = new ArrayList<>();

        for (Sorvete sorvete : sorvetes) {
            nomesSabores.addAll(obterNomesSabores(sorvete.getSabores()));
            descricoesTipos.add(sorvete.getTipoSorvete().getDescricao());
        }

        relatorio.put("listaSorvetes", descricoesTipos);
        relatorio.put("saboresVendidos", nomesSabores);
        relatorio.put("dia", dia);
        return relatorio;
    }

    private List<String> obterSabores(Sorvete sorvete) {
        List<String> sabores = new ArrayList<>();
        if (sorvete.getSabores() != null) {
            for (Sabor sabor : sorvete.getSabores()) {
                sabores.add(sabor.getNome());
            }
        }
        return sabores;
    }

    private List<String> obterNomesSabores(List<Sabor> sabores) {
        List<String> nomesSabores = new ArrayList<>();
        for (Sabor sabor : sabores) {
            nomesSabores.add(sabor.getNome());
        }
        return nomesSabores;
    }
}