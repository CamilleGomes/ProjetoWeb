package com.example.isyscreamcamille.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.isyscreamcamille.model.Sabor;
import com.example.isyscreamcamille.repository.SaborRepository;

@RestController
@RequestMapping("/sabores")
public class SaboresController {

    @Autowired
    private SaborRepository saborRepository;

    @PostMapping
    public void createSabor(@RequestBody Sabor sabor) throws SQLException {
        saborRepository.save(sabor);
    }

    @GetMapping("/{codigo}")
    public Sabor readSabor(@PathVariable int codigo) throws SQLException {
        return saborRepository.findById(codigo).orElse(null);
    }

    @GetMapping
    public List<Sabor> readAllSabores() throws SQLException {
        return (List<Sabor>) saborRepository.findAll();
    }

    @PutMapping("/{codigo}")
    public void updateSabor(@PathVariable int codigo, @RequestBody Sabor sabor) throws SQLException {
        sabor.setCodigo(codigo);
        saborRepository.save(sabor);
    }

    @DeleteMapping("/{codigo}")
    public void deleteSabor(@PathVariable int codigo) throws SQLException {
        saborRepository.deleteById(codigo);
    }
}



