package com.example.isyscreamcamille.model;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
@Entity
public class Sabor {
   @Id
   @GeneratedValue(strategy = GenerationType.AUTO)
   private int codigo;
   private String nome;
   private String descricao;
   @ManyToMany(mappedBy = "sabores")
   @JsonIgnore
   private List<Sorvete> sorvetes;
   public int getCodigo() {
       return codigo;
   }
   public void setCodigo(int codigo) {
       this.codigo = codigo;
   }
   public String getNome() {
       return nome;
   }
   public void setNome(String nome) {
       this.nome = nome;
   }
   public String getDescricao() {
       return descricao;
   }
   public void setDescricao(String descricao) {
       this.descricao = descricao;
   }
   public List<Sorvete> getSorvetes() {
       return sorvetes;
   }
   public void setSorvetes(List<Sorvete> sorvetes) {
       this.sorvetes = sorvetes;
   }
   public void addSorvete(Sorvete sorvete) {
       if (this.sorvetes == null) {
           this.sorvetes = new ArrayList<>();
       }
       this.sorvetes.add(sorvete);
   }
   @Override
   public int hashCode() {
       return Objects.hash(codigo, nome, descricao);
   }
   @Override
   public boolean equals(Object obj) {
       if (this == obj) return true;
       if (obj == null || getClass() != obj.getClass()) return false;
       Sabor sabor = (Sabor) obj;
       return codigo == sabor.codigo &&
               Objects.equals(nome, sabor.nome) &&
               Objects.equals(descricao, sabor.descricao);
   }
   @Override
   public String toString() {
       return "Sabor{" +
               "codigo=" + codigo +
               ", nome='" + nome + '\'' +
               ", descricao='" + descricao + '\'' +
               '}';
   }
}
