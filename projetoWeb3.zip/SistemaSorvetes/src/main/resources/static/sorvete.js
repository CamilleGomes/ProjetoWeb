document.addEventListener("DOMContentLoaded", function () {
    const sorveteForm = document.getElementById("sorveteForm");
    const tipoSorveteSelect = document.getElementById("tipo");
    const saboresFieldset = document.querySelector("fieldset");
    const dataCompraInput = document.getElementById("dataCompra");
    const qntBolasInput = document.getElementById("qntBolas");
    const relatorioDiaSelect = document.getElementById("relatorioDia"); // Adicione esta linha

    let tiposSorveteData = [];
    let saboresData = [];

    async function getTiposSorvete() {
        try {
            const response = await fetch('http://localhost:8080/tipos-sorvete');
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Erro ao obter tipos de sorvete do backend. Status: ${response.status}. Mensagem: ${errorText}`);
            }
            tiposSorveteData = await response.json();

            tiposSorveteData.forEach(tipo => {
                const option = document.createElement("option");
                option.value = tipo.codigo;
                option.textContent = tipo.tipo;
                option.dataset.qntBolas = tipo.qntBolas;
                tipoSorveteSelect.appendChild(option);
            });

            tipoSorveteSelect.addEventListener("change", function () {
                const tipoSelecionado = tipoSorveteSelect.value;
                const tipoEncontrado = tiposSorveteData.find(tipo => tipo.codigo === parseInt(tipoSelecionado));
                preencherInformacoesTipoSorvete(tipoEncontrado);
            });
        } catch (error) {
            console.error('Erro ao obter tipos de sorvete:', error.message);
        }
    }

    async function getSabores() {
        try {
            const response = await fetch('http://localhost:8080/sabores');
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Erro ao obter sabores do backend. Status: ${response.status}. Mensagem: ${errorText}`);
            }
            saboresData = await response.json();
            saboresData.forEach(sabor => {
                const checkbox = document.createElement("input");
                checkbox.type = "checkbox";
                checkbox.name = "sabor";
                checkbox.value = sabor.codigo;
                const label = document.createElement("label");
                label.appendChild(checkbox);
                label.appendChild(document.createTextNode(sabor.nome));
                saboresFieldset.appendChild(label);
            });
        } catch (error) {
            console.error('Erro ao obter sabores:', error.message);
        }
    }

    function preencherInformacoesTipoSorvete(tipo) {
        if (tipo) {
            console.log('Preencher informações do tipo de sorvete:', tipo);
            qntBolasInput.value = tipo.qntBolas || 0;
        } else {
            console.error('Tipo de sorvete indefinido.');
        }
    }

    getTiposSorvete();
    getSabores();

    sorveteForm.addEventListener("submit", async function (event) {
        event.preventDefault();

        const tipoSelecionado = tipoSorveteSelect.value;
        const saboresSelecionados = Array.from(document.querySelectorAll('input[name="sabor"]:checked')).map(checkbox => ({ sabor_id: checkbox.value }));
        const dataCompra = dataCompraInput.value;
        const qntBolas = tipoSorveteSelect.options[tipoSorveteSelect.selectedIndex].dataset.qntBolas;

        if (!verificarLimiteSabores(tipoSelecionado, saboresSelecionados)) {
            return;
        }

        const data = {
            tipoSorvete: {
                codigo: tipoSelecionado,
                tipo: tipoSorveteSelect.options[tipoSorveteSelect.selectedIndex].textContent,
            },
            sabores: saboresSelecionados,
            qntBolas: qntBolas,
        };

        const requestOptions = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        };

        try {
            const response = await fetch('http://localhost:8080/sorvetes', requestOptions);

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Erro ao enviar dados para o backend. Status: ${response.status}. Mensagem: ${errorText}`);
            }

            const responseData = await response.json();
            console.log('Resposta do backend:', responseData);
        } catch (error) {
            console.error('Erro:', error.message);
            alert('Erro ao processar a solicitação. Tente novamente.');
        }

        sorveteForm.reset();
    });

    function verificarLimiteSabores(tipoSelecionado, saboresSelecionados) {
        let limiteSabores;
        const tipoEncontrado = tiposSorveteData.find(tipo => tipo.codigo === parseInt(tipoSelecionado));

        if (!tipoEncontrado) {
            alert("Tipo de sorvete não encontrado");
            return false;
        }

        limiteSabores = tipoEncontrado.limiteSabores;
        const qntBolas = tipoEncontrado.qntBolas;

        if (saboresSelecionados.length > qntBolas) {
            alert(`O tipo de sorvete ${tipoSelecionado} permite apenas ${qntBolas} sabores.`);
            return false;
        }

        if (saboresSelecionados.length > limiteSabores) {
            alert(`O tipo de sorvete ${tipoSelecionado} permite no máximo ${limiteSabores} sabores.`);
            return false;
        }

        return true;
    }

    // Adicionando a função para gerar o relatório
    function gerarRelatorio() {
        const diaSelecionado = relatorioDiaSelect.value;
        // Redireciona para a página de relatório com o parâmetro dia na URL
        window.location.href = `relatorio.html?dia=${diaSelecionado}`;
    }
});