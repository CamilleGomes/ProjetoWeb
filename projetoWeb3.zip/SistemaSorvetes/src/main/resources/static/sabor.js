/* global fetch */

document.addEventListener("DOMContentLoaded", function () {
    const saborForm = document.getElementById("saborForm");

    // Lista de sabores
    const saboresPermitidos = [
        "chocolate",
        "baunilha",
        "morango",
        "brigadeiro",
        "flocos",
        "coco",
        "napolitano",
        "maracujá"
    ];

    saborForm.addEventListener("submit", async function (event) {
        event.preventDefault();

        const nomeSaborInput = document.getElementById("nomeSabor");
        const descricaoSaborInput = document.getElementById("descricaoSabor");

        const nomeSabor = nomeSaborInput.value.toLowerCase(); // Converter para minúsculas para evitar problemas de caixa
        const descricaoSabor = descricaoSaborInput.value;

        // Verificar se o sabor está na lista de sabores permitidos
        if (!saboresPermitidos.includes(nomeSabor)) {
            alert("Sabor inválido. Escolha um sabor da lista permitida.");
            nomeSaborInput.focus(); // Focar no campo de entrada de sabor
            return;
        }

        try {
            
            const data = {
                nome: nomeSabor,
                descricao: descricaoSabor
            };

            
            const requestOptions = {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            };

            // Enviar a requisição usando Fetch
            const response = await fetch('http://localhost:8080/sabores', requestOptions);

            if (!response.ok) {
                throw new Error('Erro ao enviar dados para o backend');
            }

            const responseData = await response.json();

           
            console.log('Resposta do backend:', responseData);

            
            saborForm.reset();
            nomeSaborInput.focus(); 

         
            alert('Sabor registrado com sucesso!');

        } catch (error) {
            console.error('Erro:', error);
            alert('Erro ao processar a solicitação. Tente novamente.');
        }
    });
});