package weatherapp.pdm

data class RegistrationResult(val success: Boolean)
