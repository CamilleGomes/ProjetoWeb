document.addEventListener("DOMContentLoaded", function () {
    const tipoSorveteForm = document.getElementById("tipoSorveteForm");

    tipoSorveteForm.addEventListener("submit", async function (event) {
        event.preventDefault();

        const tipo = document.getElementById("tipo").value;
        const qntBolasInput = document.getElementById("qntBolas").value;
        const peso = document.getElementById("peso").value;
        const descricao = document.getElementById("descricao").value;
        const valor = document.getElementById("valor").value;

        
        const data = {
            tipo: tipo,
            qntBolas: qntBolasInput,
            peso: peso,
            descricao: descricao,
            valor: valor
        };

        
        const requestOptions = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        };

        try {
            
            const response = await fetch('http://localhost:8080/tipos-sorvete', requestOptions);
            
            if (!response.ok) {
                throw new Error('Erro ao enviar dados para o backend');
            }

            const responseData = await response.json();
           
            console.log('Resposta do backend:', responseData);
        } catch (error) {
            console.error('Erro:', error);
        }

        tipoSorveteForm.reset();
    });
});
