package com.example.isyscreamcamille.model;
import java.util.Date;
import java.util.List;
import org.hibernate.annotations.CreationTimestamp;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
@Entity
public class Sorvete {
   @Id
   @GeneratedValue(strategy = GenerationType.AUTO)
   private int codigo;
   @CreationTimestamp
   private Date dataCompra;
   @ManyToOne
   @JoinColumn(name = "tipo_sorvete_id", referencedColumnName = "codigo")
   private TipoSorvete tipoSorvete;
   @ManyToMany(cascade = CascadeType.ALL)
   @JoinTable(
           name = "sorvete_sabores",
           joinColumns = @JoinColumn(name = "sorvete_id"),
           inverseJoinColumns = @JoinColumn(name = "sabor_id")
   )
   private List<Sabor> sabores;
   public int getCodigo() {
       return codigo;
   }
   public void setCodigo(int codigo) {
       this.codigo = codigo;
   }
   public Date getDataCompra() {
       return dataCompra;
   }
   public void setDataCompra(Date dataCompra) {
       this.dataCompra = dataCompra;
   }
   public TipoSorvete getTipoSorvete() {
       return tipoSorvete;
   }
   public void setTipoSorvete(TipoSorvete tipoSorvete) {
       this.tipoSorvete = tipoSorvete;
   }
   public List<Sabor> getSabores() {
       return sabores;
   }
   public void setSabores(List<Sabor> sabores) {
       this.sabores = sabores;
   }
   public void addSabor(Sabor sabor) {
       this.sabores.add(sabor);
   }
   public Sabor getPrimeiroSabor() {
       if (sabores != null && !sabores.isEmpty()) {
           return sabores.get(0);
       } else {
           return null;
       }
   }
   @Override
   public String toString() {
       return "Sorvete{" +
               "codigo=" + codigo +
               ", dataCompra=" + dataCompra +
               ", tipoSorvete=" + tipoSorvete +
               ", sabores=" + sabores +
               '}';
   }
}

