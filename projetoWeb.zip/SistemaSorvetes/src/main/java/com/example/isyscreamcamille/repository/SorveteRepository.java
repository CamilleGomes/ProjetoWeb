package com.example.isyscreamcamille.repository;


import org.springframework.data.repository.CrudRepository;


import com.example.isyscreamcamille.model.Sorvete;




public interface SorveteRepository extends CrudRepository<Sorvete, Integer> {

    
}
