package com.example.isyscreamcamille.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.isyscreamcamille.model.Sabor;

public interface SaborRepository extends CrudRepository<Sabor, Integer> {
    Sabor findByNome(String nome);
}
