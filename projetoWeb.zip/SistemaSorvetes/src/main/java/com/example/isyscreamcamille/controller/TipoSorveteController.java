package com.example.isyscreamcamille.controller;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.isyscreamcamille.model.TipoSorvete;
import com.example.isyscreamcamille.repository.TipoSorveteRepository;

@RestController
@RequestMapping("/tipos-sorvete")
public class TipoSorveteController {

    private final Logger log = LoggerFactory.getLogger(TipoSorveteController.class);

    @Autowired
    private TipoSorveteRepository tipoSorveteRepository;

    @PostMapping
    public void createTipoSorvete(@RequestBody TipoSorvete tipoSorvete) throws SQLException {
        tipoSorveteRepository.save(tipoSorvete);
    }

    @GetMapping("/{codigo}")
    public TipoSorvete readTipoSorvete(@PathVariable int codigo) throws SQLException {
        return tipoSorveteRepository.findById(codigo).orElse(null);
    }

    @GetMapping
    public List<TipoSorvete> readAllTiposSorvete() {
        try {
            return (List<TipoSorvete>) tipoSorveteRepository.findAll();
        } catch (Exception e) {
            
            log.error("Erro ao obter tipos de sorvete:", e);
            return Collections.emptyList();
        }
    }

    @PutMapping("/{codigo}")
    public void updateTipoSorvete(@PathVariable int codigo, @RequestBody TipoSorvete tipoSorvete) throws SQLException {
        tipoSorvete.setCodigo(codigo);
        tipoSorveteRepository.save(tipoSorvete);
    }

    @DeleteMapping("/{codigo}")
    public void deleteTipoSorvete(@PathVariable int codigo) throws SQLException {
        tipoSorveteRepository.deleteById(codigo);
    }
}
