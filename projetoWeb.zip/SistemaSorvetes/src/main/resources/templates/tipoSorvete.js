/* global fetch */

document.addEventListener("DOMContentLoaded", function () {
    const tipoSorveteForm = document.getElementById("tipoSorveteForm");

    tipoSorveteForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const tipo = document.getElementById("tipo").value;
        const qntBolas = document.getElementById("qntBolas").value;
        const peso = document.getElementById("peso").value;
        const descricao = document.getElementById("descricao").value;
        const valor = document.getElementById("valor").value;

        // Verificar se o TipoSorvete foi escolhido corretamente
        if (qntBolas <= 0) {
            alert("A quantidade de bolas deve ser maior que zero.");
            return;
        }

        // Verificar a quantidade máxima de bolas permitida para o tipo de sorvete escolhido
        let maxBolas;
        switch (tipo.toLowerCase()) {
            case "copo pequeno":
                maxBolas = 3;
                break;
            case "copo médio":
                maxBolas = 6;
                break;
            case "copo grande":
                maxBolas = 10;
                break;
            default:
                alert("Tipo de sorvete inválido");
                return;
        }

        if (qntBolas > maxBolas) {
            alert(`O tipo de sorvete ${tipo} permite no máximo ${maxBolas} bolas.`);
            return;
        }

        // Criar um objeto com os dados a serem enviados
        const data = {
            tipo: tipo,
            qntBolas: qntBolas,
            peso: peso,
            descricao: descricao,
            valor: valor
        };

        // Opções da requisição
        const requestOptions = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        };

        // Enviar a requisição usando Fetch
        fetch('http://localhost:8080/tipos-sorvete', requestOptions)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erro ao enviar dados para o backend');
                }
                return response.json();
            })
            .then(data => {
                // Processar a resposta do backend, se necessário
                console.log('Resposta do backend:', data);
            })
            .catch(error => {
                console.error('Erro:', error);
            });

        // Limpar o formulário (opcional)
        tipoSorveteForm.reset();
    });
});
