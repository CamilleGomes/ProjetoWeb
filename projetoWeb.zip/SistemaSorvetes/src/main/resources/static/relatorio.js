document.addEventListener("DOMContentLoaded", function () {
    const urlParams = new URLSearchParams(window.location.search);
    const diaSelecionado = urlParams.get('dia');
    const relatorioContent = document.getElementById("relatorioContent");

    
    fetch(`http://localhost:8080/sorvetes/relatorio/${diaSelecionado}`)
        .then(response => response.json())
        .then(relatorio => {
            
            relatorioContent.innerHTML = `
                <p>Quantidade Total de Sorvetes Vendidos: ${relatorio.quantidadeTotal}</p>
                <p>Quantidade de Sorvetes Vendidos por Sabor: ${JSON.stringify(relatorio.saboresVendidos)}</p>
                <p>Dia: ${relatorio.dia}</p>
            `;
        })
        .catch(error => {
            console.error('Erro ao obter relatório:', error);
            relatorioContent.innerText = 'Erro ao obter relatório. Tente novamente.';
        });
});
