/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpe.recife.model.negocio;

/**
 *
 * @author ALUNO
 */
public class Doguinho {
    
    private int codigo;
    private String cor;
    private String porte;
    private String raca;
    private String observacao;
    private String sexo;
    private int idadeAparente;
    private String deficienciaAparente;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getPorte() {
        return porte;
    }

    public void setPorte(String porte) {
        this.porte = porte;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public String getDeficienciaAparente() {
        return deficienciaAparente;
    }

    public void setDeficienciaAparente(String deficienciaAparente) {
        this.deficienciaAparente = deficienciaAparente;
    }

    

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public int getIdadeAparente() {
        return idadeAparente;
    }

    public void setIdadeAparente(int idadeAparente) {
        this.idadeAparente = idadeAparente;
    }
    
    
    
    
}
